import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.widget.Toast;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class PermissionsHelper {
    private static final int SMS_PERMISSION_CODE = 123;
    private Activity mActivity;

    public PermissionsHelper(Activity activity) {
        mActivity = activity;
    }

    public void requestSmsPermission() {
        if (ContextCompat.checkSelfPermission(mActivity, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(mActivity, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
        } else {
            sendSmsAlert();
        }
    }

    public void handlePermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                sendSmsAlert();
            } else {
                Toast.makeText(mActivity, "SMS permissions denied. App will function without sending SMS alerts.", Toast.LENGTH_LONG).show();
            }
        }
    }

    private void sendSmsAlert() {
    }
}
