package com.example.elirubincalverteventtrackingapp

import android.R
import android.database.sqlite.SQLiteDatabase
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TableLayout


class LoginActivity : AppCompatActivity() {
    private var usernameField: EditText? = null
    private var passwordField: EditText? = null
    private var dbHelper: DatabaseHelper? = null
    private val db: SQLiteDatabase? = null
    protected fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        dbHelper = DatabaseHelper(this)
        usernameField = findViewById(R.id.usernameField)
        passwordField = findViewById(R.id.passwordField)
        val loginButton: Button = findViewById(R.id.loginButton)
        loginButton.setOnClickListener {
            // Logic for logging in user
        }
        val createAccountButton: Button = findViewById(R.id.createAccountButton)
        createAccountButton.setOnClickListener {
            // Logic for registering user
        }
    }
}

class EventsActivity : AppCompatActivity() {
    private var dataInputField1: EditText? = null
    private var dataInputField2: EditText? = null
    private var dataTable: TableLayout? = null
    private var dbHelper: DatabaseHelper? = null
    protected fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_events)
        dbHelper = DatabaseHelper(this)
        dataTable = findViewById(R.id.dataTable)
        dataInputField1 = findViewById(R.id.dataInputField1)
        dataInputField2 = findViewById(R.id.dataInputField2)
        val addDataButton: Button = findViewById(R.id.addDataButton)
        addDataButton.setOnClickListener {
            // Logic to add data to database and update table
        }
    }
}
